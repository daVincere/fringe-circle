//$( document ).ready(function() {
//    $('.contact-button').click(function() {
//	$('body').addClass('hidden-body')
//    });
//});



$(document).ready(function(){
   
    $('#popup').on('click',function(){
      
            $('body').addClass('hidden-body');
			$('.overley-bg').show();
		    $('.disc-post,.find-locate').show()
        });
		
		 $('.close-btn').on('click',function(){
		 $('body').removeClass('hidden-body');
		 $('.overley-bg').hide();
		    $('.disc-post,.find-locate').hide()
		 
	});
		});
		
		
		
		$(document).ready(function(){
   
    $('#signIn').on('click',function(){
      
            $('body').addClass('hidden-body');
			$('.overley-bg').show();
		    $('.login-popup').show()
        });
		
		 $('.close-btn').on('click',function(){
		 $('body').removeClass('hidden-body');
		 $('.overley-bg').hide();
		    $('.login-popup').hide()
		 
	});
		});
		
		
		$(document).ready(function(){
   
    $('#regIn').on('click',function(){
      
            $('body').addClass('hidden-body');
			$('.overley-bg').show();
		    $('.register-popup').show()
        });
		
		 $('.close-btn').on('click',function(){
		 $('body').removeClass('hidden-body');
		 $('.overley-bg').hide();
		    $('.register-popup').hide()
		 
	});
		});